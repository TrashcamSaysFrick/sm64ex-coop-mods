-- name: Mario Ascends
-- description: Hey guys its me, Trashcam. This is my first mod, its pretty dumb. Get a star and ascend fue to your gamingship. So enjoy this! NOTE: It only works with Mario because whacky C files and stuff. Also I left the anim in the files if your interested in that.

smlua_audio_utils_replace_sequence(0x01, 0x19, 100, "Ascend")