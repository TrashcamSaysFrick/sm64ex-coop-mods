-- name: [CS] Garn47
-- description: It's Grahsome
--[[
    API Documentation for Character Select can be found below:
    https://github.com/Squishy6094/character-select-coop/blob/main/API-doc.md
]]

local E_MODEL_GARN47_MODEL = smlua_model_util_get_id("garn47_geo")

local TEXT_MOD_NAME = "Garn47 Pack"

local VOICETABLE_GARN47 = {
    [CHAR_SOUND_ATTACKED] = 'Garnbump.ogg',
    [CHAR_SOUND_DOH] = 'Garnbump.ogg',
    [CHAR_SOUND_DROWNING] = 'Garnfallingdownstairs.ogg',
    [CHAR_SOUND_DYING] = 'Garnfallingdownstairs.ogg',
    [CHAR_SOUND_HERE_WE_GO] = 'Garnular1.ogg',
    [CHAR_SOUND_MAMA_MIA] = 'Garn_whatwasthatshort.ogg',
    [CHAR_SOUND_ON_FIRE] = 'GarnScream.ogg',
    [CHAR_SOUND_OOOF] = 'GarnHm.ogg',
    [CHAR_SOUND_OOOF2] = 'GarnHm.ogg',
    [CHAR_SOUND_WAAAOOOW] = 'GarnScream.ogg',
    [CHAR_SOUND_LETS_A_GO] = 'Garn47_intro.ogg',
    [CHAR_SOUND_PUNCH_HOO] = 'GarnShoot.ogg',
    [CHAR_SOUND_PUNCH_WAH] = 'GarnShoot.ogg',
    [CHAR_SOUND_PUNCH_YAH] = 'GarnShoot.ogg',
    [CHAR_SOUND_YAHOO] = 'GarnHm.ogg',
    [CHAR_SOUND_YAHOO_WAHA_YIPPEE] = 'Garnflap1.ogg', 'Garnflap2.ogg', 'Garnflap3.ogg',
    [CHAR_SOUND_YAH_WAH_HOO] = 'Garnflap1.ogg', 'Garnflap2.ogg', 'Garnflap3.ogg',
}

local PALETTE_GARN47 = {
    [PANTS]  = "020301",
    [SHIRT]  = "52562b",
    [GLOVES] = "52562b",
    [SHOES]  = "58a087",
    [HAIR]   = "020301",
    [SKIN]   = "52562b",
    [CAP]    = "020301",
    [EMBLEM] = "020301",
}

if _G.charSelectExists then
    _G.charSelect.character_add("Garn47", {"In Theaters"}, "Trashcam", {r = 255, g = 185, b = 139}, E_MODEL_GARN47_MODEL, CT_MARIO, get_texture_info("garn47"))
    _G.charSelect.character_add_palette_preset(E_MODEL_GARN47_MODEL, PALETTE_GARN47)

    _G.charSelect.character_add_voice(E_MODEL_GARN47_MODEL, VOICETABLE_GARN47)
    hook_event(HOOK_CHARACTER_SOUND, function (m, sound)
    if _G.charSelect.character_get_voice(m) == VOICETABLE_GARN47 then return _G.charSelect.voice.sound(m, sound) end
    end)
    hook_event(HOOK_MARIO_UPDATE, function (m)
        if _G.charSelect.character_get_voice(m) == VOICETABLE_GARN47 then return _G.charSelect.voice.snore(m) end
    end)
else
    djui_popup_create("\\#ffffdc\\\n"..TEXT_MOD_NAME.."\nRequires the Character Select Mod\nto use as a Library!\n\nPlease turn on the Character Select Mod\nand Restart the Room!", 6)
end